<header id="header" class="clearfix">
	<div class="container_12">
		<h1 id="logo_postnet"><a href="/" title="PostNet Curitiba">PostNet</a></h1>
		<nav class="menu servicos">
			<h3 class="menu_title">Conheça nossos serviços</h3>
			<ul>
				<li><a href="postagem.php" title="Postagem">Postagem</a></li>
				<li>• <a href="grafica.php" title="Gráfica">Gráfica</a></li>
				<li>• <a href="escritorio.php" title="Escritório">Escritório</a></li>
			</ul>
		</nav>
		<nav class="menu contato">
			<h3 class="menu_title">Entre em contato com a PostNet</h3>
			<ul>
				<li><a href="contato.php" title="Fale conosco">Fale conosco</a></li>
				<li>• <a href="como-chegar.php" title="Como chegar">Como chegar</a></li>
				<li>• <a href="sobre-nos.php" title="Sobre nós">Sobre nós</a></li>
			</ul>
		</nav>
	</div>
</header>