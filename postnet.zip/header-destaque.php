<div id="header_destaque">
	<p><strong>Nossa loja em Curitiba</strong> <br />
	   Rua Visconde de Nacar, 1505 lj 2 <br />
	   (41) <strong>3044 2728</strong> </p>
</div>