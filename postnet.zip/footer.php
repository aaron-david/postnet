<footer class="grid_12 clearfix red_line_top">
	<div class="grid_6 alpha">
		<p><b class="red">Postnet Curitiba</b> <br />
		Rua Visconde de Nacar, 1505 lj 2 - Centro - Curitiba - PR - (41) 3044 2728</p>
		<span class='st_facebook_hcount' displayText='Facebook'></span>
		<span class='st_twitter_hcount' displayText='Tweet'></span>
		
		<div class="fb-like" data-href="https://www.facebook.com/postnet.curitiba" data-send="false" data-width="450" data-show-faces="true"></div>
		
	</div>
	<div id="logos_parceiros" class="grid_6 omega">
		<small class="clearfix">Serviços de postagem:</small>
		<img src="images/parceiro-fedex.png" width="126" height="49" alt="Fedex">
		<img src="images/parceiro-ups.png" width="60" height="49" alt="UPS">
		<img src="images/parceiro-dhl.png" width="118" height="49" alt="DHL">
		<img src="images/parceiro-tam-cargo.png" width="102" height="49" alt="TAM Cargos">
	</div>
	
</footer>